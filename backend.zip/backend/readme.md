# Proxy server for MovieDB app

In orderto run the MovieDB app you need to deploy this backend folder to server.

add .env file

```
API_KEY = "?api_key=<Your tmdb api key>"
OMDB_API_KEY="<your ombd api key>"
PORT=5000
```
